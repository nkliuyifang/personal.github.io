1. Data preperation for Penn dataset:

   Penn_RGB/labels/0001.mat
   Penn_RGB/data/0001/000001.jpg
   Penn_RGB/data/0001/000001.mat
               ...

   "0001" is the first video;
   "0001.mat" contains the action label of the video;
   "000001.jpg" is the first video frame of the video;
   "000001.mat" is the joint estimation maps of the frame.

2. Open Matlab, and run:
   
   att_map_14_rgb_f_s_t.m
   map_14_img.m

   They create att-DTI and DPI features.

3. Open python, and run:
   
   python sheet.py
   python Penn.py

   They predict action labels for testing set of Penn dataset.









