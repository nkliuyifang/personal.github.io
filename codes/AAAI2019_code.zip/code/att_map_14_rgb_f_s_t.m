clc;
clear;

map_14_rgb_f_dir = 'att_map_14_rgb_f/feature';
mkdir(map_14_rgb_f_dir);
map_14_rgb_s_dir = 'att_map_14_rgb_s/feature';
mkdir(map_14_rgb_s_dir);
map_14_rgb_t_dir = 'att_map_14_rgb_t/feature';
mkdir(map_14_rgb_t_dir);

ct = 0;
Dir00 = dir(['Penn_RGB/']);
for ss = 3:size(Dir00,1)
    Dir0 = dir(['Penn_RGB/',Dir00(ss,1).name]);
    for k = 3:size(Dir0,1)
        ct = ct + 1;
        
        clc;
        disp(ct);
        %disp([size(Dir0,1)-2 k-2]);
        Dir1 = dir(['Penn_RGB/',Dir00(ss,1).name,'/',Dir0(k,1).name,'/*.jpg']);

        LENGTH = size(Dir1,1);
        map_14_rgb0 = [];
        
        for j = 1:LENGTH
            file = ['Penn_RGB/',Dir00(ss,1).name,'/',Dir0(k,1).name,'/',Dir1(j,1).name];
            
            load([file(1,1:end-4),'.mat']);
            heatmap = sum(heatmap(:,:,[1:14]),3);
            heatmap = heatmap - min(min(heatmap));
            heatmap = heatmap ./ (max(max(heatmap))+0.0001);
            
            img = imread([file(1,1:end-4),'.jpg']);
            img = rgb2gray(img);
            img = double(img);
            if j == 1
               map_14_rgb0 = zeros(LENGTH,size(img,1),size(img,2)); 
            end
            map_14_rgb0(j,:,:) = img.*heatmap;
        end

        map_14_rgb = imresize(map_14_rgb0,[224, 224]);
        map_14_rgb = permute(map_14_rgb,[3,1,2]);
        skeleton = imresize(map_14_rgb,[14, 224]);
        skeleton = skeleton - min(min(min(skeleton)));
        skeleton = skeleton / (max(max(max(skeleton)))+1e-10);
        skeleton1 = uint8(skeleton * 255);
        
        map_14_rgb = permute(map_14_rgb0,[3,2,1]);
        map_14_rgb = imresize(map_14_rgb,[224, 224]);
        map_14_rgb = permute(map_14_rgb,[3,1,2]);
        skeleton = imresize(map_14_rgb,[14, 224]);
        skeleton = skeleton - min(min(min(skeleton)));
        skeleton = skeleton / (max(max(max(skeleton)))+1e-10);
        skeleton0 = uint8(skeleton * 255);
        
        map_14_rgb = permute(map_14_rgb0,[1,3,2]);
        map_14_rgb = imresize(map_14_rgb,[224, 224]);
        map_14_rgb = permute(map_14_rgb,[3,1,2]);
        skeleton = imresize(map_14_rgb,[14, 224]);
        skeleton = skeleton - min(min(min(skeleton)));
        skeleton = skeleton / (max(max(max(skeleton)))+1e-10);
        skeleton2 = uint8(skeleton * 255);
        
        save([map_14_rgb_f_dir,'/',Dir0(k,1).name],'skeleton0');
        save([map_14_rgb_s_dir,'/',Dir0(k,1).name],'skeleton1');
        save([map_14_rgb_t_dir,'/',Dir0(k,1).name],'skeleton2');
    end
end
