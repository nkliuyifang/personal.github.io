import os

os.chdir("att_map_14_rgb_f/")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model1")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model2")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model3")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model4")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model5")




os.chdir("att_map_14_rgb_s/")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model1")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model2")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model3")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model4")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model5")



os.chdir("att_map_14_rgb_t/")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model1")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model2")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model3")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model4")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model5")



os.chdir("map_14_img/")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model1")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model2")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model3")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model4")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model5")









