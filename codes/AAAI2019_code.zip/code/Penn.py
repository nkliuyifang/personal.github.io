import numpy as np
import scipy.io as sio

######################################################################
# Load Data
####################################### 
avg_pre = 0
for kk in range(1, 6):
   print(kk)
   labels_name = 'map_14_img/model'+str(kk)+'/Label.npy'
   labels  = np.load(labels_name)
    
   pre_name = 'map_14_img/model'+str(kk)+'/Pre.npy'
   Predict_3 = np.load(pre_name)
   
   pre_name = 'att_map_14_rgb_f/model'+str(kk)+'/Pre.npy'
   Predict_0 = np.load(pre_name)

   pre_name = 'att_map_14_rgb_s/model'+str(kk)+'/Pre.npy'
   Predict_1 = np.load(pre_name)

   pre_name = 'att_map_14_rgb_t/model'+str(kk)+'/Pre.npy'
   Predict_2 = np.load(pre_name)

    
   Predict = Predict_3 #0.9032
   
   Predict = Predict_0 # att:0.8577
   Predict = Predict_1 # att:0.8961
   Predict = Predict_2 # att:0.8382
   
   Predict = Predict_3 * Predict_0 # att:0.9390
   Predict = Predict_3 * Predict_1 # att:0.9453
   Predict = Predict_3 * Predict_2 # att:0.9328
   
   Predict = Predict_0 * Predict_1 * Predict_2 # att:0.9425
   Predict = Predict_3 * Predict_0 * Predict_1 * Predict_2 # att:0.9586


    preds = Predict.argmax(axis=1)  
    correct = np.sum(preds==labels)/(preds.size*1.0)
    print('correct: {}'.format(correct))
    avg_pre = avg_pre + correct
    
    sio.savemat('Penn_'+str(kk)+'.mat', {'preds': preds, 'labels': labels})
avg_pre /= 5
print('avg:{}'.format(avg_pre))


