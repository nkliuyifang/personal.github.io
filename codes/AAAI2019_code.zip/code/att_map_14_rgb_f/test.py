from __future__ import print_function, division

import torch
import scipy.io as scio
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
from torchvision import datasets, models, transforms
import numpy as np
from torch.utils.data import TensorDataset,DataLoader,Dataset
from model import FullCNN
import torch.nn.functional as FUN
import time
import os

#os.environ["CUDA_VISIBLE_DEVICES"] = "3"
batch_size = 16#############
data_dir = 'subject/val/'############

def find_classes(data_dir):
    classes = [d for d in os.listdir(data_dir)]
    classes.sort()
    class_to_idx = {classes[i]: i for i in range(len(classes))}
    return classes, class_to_idx

def readDataset(data_dir):
    classes, class_to_idx = find_classes(data_dir)
    
    listname = None
    listlabel = None
    dir = os.path.expanduser(data_dir)
    for target in sorted(os.listdir(dir)):
        d = os.path.join(dir, target)
        if not os.path.isdir(d):
            continue
        
        for root, _,fnames in sorted(os.walk(d)):
            for fname in sorted(fnames):
                path = os.path.join(root, fname)
                label = class_to_idx[target]
                if listname is None:
                    listname = path
                    listlabel = label
                else:
                    listname = np.hstack((listname,path))
                    listlabel = np.hstack((listlabel,label))
    return listname, listlabel.astype(int)
    
class CustomDataset(Dataset):
    def __init__(self,listname,listlabel):
        super(CustomDataset, self).__init__()
        self.listname = listname
        self.listlabel = listlabel
    def __len__(self):
        return len(self.listlabel)
    def __getitem__(self, index):
        H = scio.loadmat(self.listname[index])
        H = H['skeleton']
        H = H.astype(float)
        label = self.listlabel[index]
        return (H, label)

def reloaddata():
    listname, listlabel = readDataset(data_dir)
        
    image_datasets = CustomDataset(listname,listlabel)
    dset_sizes = len(image_datasets)
    
    dset_loaders = torch.utils.data.DataLoader(image_datasets, batch_size=batch_size,
                                             shuffle=False, num_workers=1)
    return dset_loaders, dset_sizes

use_gpu = torch.cuda.is_available()
######################################################################

def test_model(model,criterion):
    model.eval()
    running_loss = 0.0
    running_corrects = 0
    cont = 0
    outPre = []
    outLabel = []
    dset_loaders, dset_sizes = reloaddata()
    # Iterate over data.
    for i, (inputs, labels) in enumerate(dset_loaders):
        #labels must to be LongTensor for CrossEntropyLoss
        #labels = torch.squeeze(labels.type(torch.LongTensor))
        if use_gpu:
            inputs = Variable(inputs.type(torch.FloatTensor).cuda())
            labels = Variable(labels.cuda())
        else:
            inputs = Variable(inputs.type(torch.FloatTensor))
            labels = Variable(labels)

        # forward
        outputs =  model(inputs)
        _, preds = torch.max(outputs.data, 1)
        loss = criterion(outputs, labels)   
        if cont==0:
            outPre = outputs.data.cpu()
            outLabel = labels.data.cpu()
        else:
            outPre = torch.cat((outPre,outputs.data.cpu()),0)
            outLabel = torch.cat((outLabel,labels.data.cpu()),0)
        # statistics
        running_loss += loss.data[0]
        running_corrects += torch.sum(preds == labels.data)
        print('Num:',cont)
        cont +=1

    print('Loss: {:.4f} Acc: {:.4f}'.format(running_loss/dset_sizes,
                    running_corrects/dset_sizes))
       
    return FUN.softmax(outPre).data.numpy(), outLabel.numpy()
    
######################################################################
#torch.cuda.set_device(2)
modelft_file = "./model/best.pth"
model_ft = torch.load(modelft_file).cuda()
criterion = nn.CrossEntropyLoss().cuda()
######################################################################
outPre, outLabel = test_model(model_ft,criterion)

np.save('./model/Pre',outPre)
np.save('./model/Label',outLabel)

