
import torch.nn as nn
#import torch
#import torch.nn.functional as F
#from torch.autograd import Variable
from torchvision import models

#fine-tuning VGG19 
class FullCNN(nn.Module):
    def __init__(self):
        super(FullCNN, self).__init__()
#        loadmodel = models.vgg19(pretrained=True)
#        loadmodel.classifier._modules["6"] = nn.Linear(4096,60)
#        self.premodel = loadmodel
#        self.bilinear = nn.Upsample(size=(224,224),mode='bilinear')

        loadmodel = models.resnet152(pretrained=True)
        loadmodel.conv1 = nn.Conv2d(14,64,kernel_size=7,stride=2,padding=3,bias=False)
        num_ftrs = loadmodel.fc.in_features
        loadmodel.fc = nn.Linear(num_ftrs, 15)
        self.premodel = loadmodel
      
    def forward(self, inputs):
        out = self.premodel(inputs)
        return out


#def preprocess(A):
#    # Get size of the adjacency matrix
#    size = len(A)
#    # Get the degrees for each node
#    degrees = []
#    for node_adjaceny in A:
#        num = 0
#        for node in node_adjaceny:
#            if node == 1.0:
#                num = num + 1
#        # Add an extra for the "self loop"
#        num = num + 1
#        degrees.append(num)
#    # Create diagonal matrix D from the degrees of the nodes
#    D = np.diag(degrees)
#    # Cholesky decomposition of D
#    D = np.linalg.cholesky(D)
#    # Inverse of the Cholesky decomposition of D
#    D = np.linalg.inv(D)
#    # Create an identity matrix of size x size
#    I = np.eye(size)
#    # Turn adjacency matrix into a numpy matrix
#    A = np.matrix(A)
#    # Create A hat
#    A_hat = A + I
#    # Return A_hat
#    return A_hat, D
#
#def preprocess_torch(A):
#    # Get size of the adjacency matrix
#    size = A.size()[0]
#    # Get the degrees for each node
#    D = Variable(torch.inverse(torch.potrf(torch.diag(torch.sum(A,1))))
#                 ,requires_grad = False)
#    A_hat = Variable(A + torch.eye(size),requires_grad = False)
#    A = Variable(A,requires_grad = False)
#    return A_hat, D,A
#
#
#class FullCNN(nn.Module):
#    def __init__(self):
#        super(FullCNN, self).__init__()
#        loadmodel = models.vgg19(pretrained=True)
#        loadmodel.classifier._modules["6"] = nn.Linear(4096,60)
#        self.premodel = loadmodel
#        self.relu = nn.ReLU() 
#        self.bilinear = nn.Upsample(size=224,mode='bilinear')
#        self.W1 = Variable(torch.randn(25, 75).type(torch.FloatTensor), requires_grad=True).cuda()
#        self.W2 = Variable(torch.randn(75, 25).type(torch.FloatTensor), requires_grad=True).cuda()
#        self.W3 = Variable(torch.randn(25, 1).type(torch.FloatTensor), requires_grad=True).cuda()
#
#    def GCNet(self,inputa,inputb):
#        batchsize,N = inputa.size()[0],inputa.size()[3]
#        out = Variable(torch.zeros(batchsize,25,N))
#        for i in range(batchsize):
#            for j in range(N):
#                a = torch.squeeze(inputa[i,:,:,j])
#                b = torch.squeeze(inputb[i,:,:,j])
##                norma = torch.sqrt(torch.matmul(a,a.transpose(1,0)))+0.00001
##                normb = torch.sqrt(torch.matmul(b,b.transpose(1,0)))+0.00001
#                x = (torch.matmul(a,b.transpose(1,0)))
#                D, A,x = preprocess_torch(x)
#                hidden_layer_1 = F.tanh(D.mm(A).mm(D).mm(x).mm(W1))
#                hidden_layer_2 = F.tanh(D.mm(A).mm(D).mm(hidden_layer_1).mm(W2))
#                temp = F.tanh(D.mm(A).mm(D).mm(hidden_layer_2).mm(W3))
#                out[i,:,j] = temp
#                
#        return out
#
#    def Getcolor(self,input):
#        
#        B_F = self.GCNet(input[:,:,:,1:-1],input[:,:,:,1:-1]) 
#        C_F = self.GCNet(input[:,:,:,1:-1],input[:,:,:,:-2])
#        A_F = self.GCNet(input[:,:,:,1:-1],input[:,:,:,2:])
#        out = torch.cat((B_F,C_F,A_F),1)
#        return out
#
#    def forward(self, inputs):
##        image = torch.stack([self.cnn(torch.unsqueeze(inputs[:,i,:,:],1)).view(
##                             -1,3,64).contiguous() for i in range(64)],3)
#        out   = self.relu(self.premodel(self.bilinear(inputs)))
#        return out
##
#class CNNLSTM(nn.Module):
#    def __init__(self):
#        super(CNNLSTM, self).__init__()
#        self.lstm = nn.LSTM( input_size  = 9,
#                    hidden_size = 60,         # rnn hidden unit
#                    num_layers  =  3,           # number of rnn layer
#                    batch_first = True)
#        self.cnn = nn.Sequential(
#                    nn.Conv2d(64,64,5,1,2,groups=64),
#                    nn.LeakyReLU(0.2),
#                    nn.MaxPool2d(2))
#        
##        self.feature = nn.Sequential(
##                    nn.Linear(576,576),
##                    nn.LeakyReLU(0.2),
##                    nn.Linear(576,60),
##                    nn.ReLU())        
#        
#    def forward(self, inputs):
#        
#        output = self.cnn(inputs)
#        output = self.cnn(output)
#        output = self.cnn(output)
#        input_lstm = output.view(-1,64,9).contiguous()
#        output_lstm,_ = self.lstm(input_lstm)
#        out = output_lstm[:,-1,:]
#        return out

#class GenNet(nn.Module):
#    def __init__(self):
#        super(GenNet, self).__init__()
#        self.GenNet = nn.Sequential(
#                nn.Conv2d(3,64,3,1,1),
#                nn.ReLU(),
#                nn.Conv2d(64,64,3,1,1),
#                nn.ReLU(),
#                nn.Conv2d(64,64,3,1,1),
#                nn.ReLU(),
#                nn.Conv2d(64,64,3,1,1),
#                nn.ReLU(),
#                nn.Conv2d(64,3,3,1,1),
#                nn.Tanh())
#        
#    def forward(self, inputs):
#        out   = self.GenNet(inputs) + inputs
#        return out
  
#class DropoutFrme(nn.Module):
#    def __init__(self):
#        super(DropoutFrme, self).__init__()
#        self.bilinear = nn.Upsample(size=224,mode='bilinear')
#        
#    def forward(self, inputs,dropoutP = 0.25):
#        B,D,S,T = inputs.size()
#        Indx = torch.LongTensor(range(T)).cuda()
#        outputs = Variable(torch.zeros(B,D,224,224)).cuda()
#        for i in range(B): 
#           SelIndex = (torch.rand(1,T)>dropoutP).cuda()
#           Sinput = torch.unsqueeze(inputs[i][:,:, Indx[SelIndex]],0)
#           outputs[i,:,:,:] = self.bilinear(Sinput)
#        return outputs
#    
  
#class GANDropoutFrame(nn.Module):
#    def __init__(self):
#        super(GANDropoutFrame, self).__init__()
#        
#        self.bilinear = nn.Upsample(size=60,mode='bilinear')
#        self.rnn = nn.LSTM(         # if use nn.RNN(), it hardly learns
#            input_size  = 180,
#            hidden_size = 1,         # rnn hidden unit
#            num_layers  =  3,          # number of rnn layer
#            batch_first = True)      # input & output will has batch size as 1s dimension. e.g. (batch, time_step, input_size)
#
#        self.softmax = nn.Softmax()
#        
#    def forward(self, inputs,dropoutN = 20):
#        ResN = inputs.size()[3] - dropoutN
#        features = inputs.view(-1,180,60).transpose(1,2)
#        prob = self.softmax(torch.squeeze(self.rnn(features)[0]))
#        indices = prob.topk(ResN,1)[1].sort(1)[0]
#        DropoutF = torch.stack([inputs[i,:,:,:].index_select(2,indices[i,:]) 
#                        for i in range(inputs.size()[0])])
#        DropoutF = self.bilinear(DropoutF)
#        outputs  = self.bilinear(DropoutF)
#        topk,indices = a.topk(3,1)
#        c = [b[i,:,:,:].index_select(2,indices[i,:]) for i in range(k)]
#        torch.stack(c)

#    index_vector = Variable(torch.masked_select(torch.arange(0, batch_size), mask_vector).long()).cuda()
#    valid_output = torch.index_select(decoder_output, 0, index_vector)
#    valid_target = torch.index_select(target_sentences[:, step], 0, index_vector)
#        return DropoutF
  

    
    
   