from __future__ import print_function, division

import torch
import scipy.io as scio
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
from torchvision import datasets, models, transforms
import numpy as np
from torch.utils.data import TensorDataset,DataLoader,Dataset
from model import FullCNN
import time
import os

#os.environ["CUDA_VISIBLE_DEVICES"] = "1"
batch_size = 16#############
data_dir = 'subject/train/'############

def find_classes(data_dir):
    classes = [d for d in os.listdir(data_dir)]
    classes.sort()
    class_to_idx = {classes[i]: i for i in range(len(classes))}
    return classes, class_to_idx

def readDataset(data_dir):
    classes, class_to_idx = find_classes(data_dir)
    
    listname = None
    listlabel = None
    dir = os.path.expanduser(data_dir)
    for target in sorted(os.listdir(dir)):
        d = os.path.join(dir, target)
        if not os.path.isdir(d):
            continue
        
        for root, _,fnames in sorted(os.walk(d)):
            for fname in sorted(fnames):
                path = os.path.join(root, fname)
                label = class_to_idx[target]
                if listname is None:
                    listname = path
                    listlabel = label
                else:
                    listname = np.hstack((listname,path))
                    listlabel = np.hstack((listlabel,label))
    return listname, listlabel.astype(int)
    
class CustomDataset(Dataset):
    def __init__(self,listname,listlabel):
        super(CustomDataset, self).__init__()
        self.listname = listname
        self.listlabel = listlabel
    def __len__(self):
        return len(self.listlabel)
    def __getitem__(self, index):
        H = scio.loadmat(self.listname[index])
        H = H['skeleton']
        H = H.astype(float)
        label = self.listlabel[index]
        return (H, label)

def reloaddata():
    listname, listlabel = readDataset(data_dir)
        
    image_datasets = CustomDataset(listname,listlabel)
    dset_sizes = len(image_datasets)
    
    dset_loaders = torch.utils.data.DataLoader(image_datasets, batch_size=batch_size,
                                             shuffle=True, num_workers=1)
    return dset_loaders, dset_sizes

use_gpu = torch.cuda.is_available()
######################################################################

def train_model(model_ft, criterion, optimizer, lr_scheduler, num_epochs=60):
   
    train_loss = []
    since = time.time()
    best_model_wts = model_ft.state_dict()
    best_acc = 0.0
    # Set model to training mode
    model_ft.train(True)
    for epoch in range(num_epochs):
        dset_loaders, dset_sizes = reloaddata()
        print('Data Size',dset_sizes)           
        print('Epoch {}/{}'.format(epoch, num_epochs - 1))
        print('-' * 10)
        # Each epoch has a training and validation phase
        optimizer = lr_scheduler(optimizer, epoch)
        
        running_loss = 0.0
        running_corrects = 0
        count = 0
        
        # Iterate over data.
        for i, (inputs, labels) in enumerate(dset_loaders):
            #labels must to be LongTensor for CrossEntropyLoss
            #labels = torch.squeeze(labels.type(torch.LongTensor))
            if use_gpu:
                inputs = Variable(inputs.type(torch.FloatTensor).cuda())
                labels = Variable(labels.cuda())
            else:
                inputs = Variable(inputs.type(torch.FloatTensor))
                labels = Variable(labels)
                        
            # zero the parameter gradients             
            outputs = model_ft(inputs)
            
            loss = criterion(outputs,labels)
            _, preds = torch.max(outputs.data, 1)   
            
#            # backward + optimize only if in training phase
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            #print output
            count +=1
            if count%30==0 or outputs.size()[0]<batch_size:
                print('Epoch:{}: loss:{:.3f}'.format(epoch,loss.data[0]))         
                train_loss.append(loss.data[0])
            # statistics
            
            running_loss += loss.data[0]
            running_corrects += torch.sum(preds == labels.data)
                
        epoch_loss = running_loss / dset_sizes
        epoch_acc = running_corrects / dset_sizes

        print('Loss: {:.4f} Acc: {:.4f}'.format(
            epoch_loss, epoch_acc))
        
        # deep copy the model
        if epoch_acc > best_acc:
            best_acc = epoch_acc
            best_model_wts = model_ft.state_dict()
        if epoch_acc > 0.98:
            break
            
    #save model         
    model_ft.load_state_dict(best_model_wts)
    model_out_path = "./model/best.pth"
    torch.save(model_ft, model_out_path)
            
    time_elapsed = time.time() - since
    print('Training complete in {:.0f}m {:.0f}s'.format(
        time_elapsed // 60, time_elapsed % 60))
    
    return train_loss
    
######################################################################
def exp_lr_scheduler(optimizer, epoch, init_lr=0.001, lr_decay_epoch=20):
    """Decay learning rate by a f#            model_out_path ="./model/W_epoch_{}.pth".format(epoch)
#            torch.save(model_W, model_out_path) actor of 0.1 every lr_decay_epoch epochs."""
    lr = init_lr * (0.1**(epoch // lr_decay_epoch))
    print('LR is set to {}'.format(lr))
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr

    return optimizer


######################################################################
######################################################################
# Finetuning the convnet
# ----------------------
# Load a pretrained model and reset final fully connected layer.
#model_ft = FullCNN()
model_ft = FullCNN()
criterion = nn.CrossEntropyLoss()
if use_gpu:
    model_ft = model_ft.cuda()
    criterion = criterion.cuda()
    model_ft = torch.nn.DataParallel(model_ft,device_ids=[0,1,2,3])

optimizer = optim.SGD(list(model_ft.parameters()),lr=0.001, 
                      momentum=0.9,weight_decay=0.0004)

######################################################################
# Train and evaluate
# ^^^^^^^^^^^^^^^^^^
train_loss = train_model(model_ft,criterion,optimizer, exp_lr_scheduler,num_epochs=60)
#np.save('train_loss_VGG.npy',train_loss)
#######################################


