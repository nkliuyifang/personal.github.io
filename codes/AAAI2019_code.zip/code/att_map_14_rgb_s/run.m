clc;
clear;
label_path = '../Penn_RGB/labels/';
path = 'feature/';
Dir = dir(path);

output_dir_subject = ['subject'];
mkdir(output_dir_subject);
mkdir([output_dir_subject,'/train']);
mkdir([output_dir_subject,'/val']);


for k = 3:size(Dir,1)
    clc;
    disp([size(Dir,1) k]);
    file = Dir(k,1).name;
    
    load([label_path,file]);
    load([path,file]);
    skeleton = double(skeleton1);
    ske_m = mean(skeleton,1);
    ske_m = repmat(ske_m,[14,1,1]);
    skeleton = skeleton - ske_m;
%     skeleton = permute(skeleton,[2,3,1]);
%     skeleton = imresize(skeleton,[224,224]);
%     skeleton = permute(skeleton,[3,1,2]);
    for j = 1:14
       temp = skeleton(j,:,:);
       temp = temp - min(min(min(temp)));
       temp = temp / (max(max(max(temp)))+1e-10);
       skeleton(j,:,:) = uint8(temp*255);
    end
    skeleton = uint8(skeleton);
    %save(['map_14_img/',Dir(k,1).name],'skeleton');
    

    if train == 1
       % train
       mkdir([output_dir_subject,'/train/action',num2str(action)]);
       save([output_dir_subject,'/train/action',num2str(action),'/',file(1,1:end-4),'.mat'],'skeleton','-v6');
    else
       % test
       mkdir([output_dir_subject,'/val/action',num2str(action)]);
       save([output_dir_subject,'/val/action',num2str(action),'/',file(1,1:end-4),'.mat'],'skeleton','-v6');
    end
end
