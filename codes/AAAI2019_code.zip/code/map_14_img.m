clc;
clear;

map_14_img_dir = 'map_14_img/feature';
mkdir(map_14_img_dir);

Dir00 = dir(['Penn_RGB/']);
for ss = 3:size(Dir00,1)
    Dir0 = dir(['Penn_RGB/',Dir00(ss,1).name]);
    for k = 3:size(Dir0,1)
        clc;
        disp([size(Dir0,1)-2 k-2]);
        Dir1 = dir(['Penn_RGB/',Dir00(ss,1).name,'/',Dir0(k,1).name,'/*.mat']);

        LENGTH = size(Dir1,1);

        map_14_img = [];
  
        for j = 1:LENGTH
            file = ['Penn_RGB/',Dir00(ss,1).name,'/',Dir0(k,1).name,'/',Dir1(j,1).name];
            load(file);
            heatmap = heatmap(:,:,[1:14]);
 
            if j == 1
                map_14_img = zeros(14,size(heatmap,1)+size(heatmap,2),LENGTH);
            end

            for m = 1:14
                temp = heatmap(:,:,m);
                map_14_img(m,:,j) = [sum(temp,1)';sum(temp,2)];
            end

        end

        skeleton = [];
        skeleton = map_14_img;
        skeleton = skeleton - min(min(min(skeleton)));
        skeleton = skeleton / (max(max(max(skeleton)))+1e-10);
        skeleton = uint8(skeleton * 255);
        save([map_14_img_dir,'/',Dir0(k,1).name],'skeleton');

    end
end
