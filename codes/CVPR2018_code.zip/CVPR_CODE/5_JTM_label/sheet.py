import os

os.chdir("/home/mfy/LMY/UTD/H2_t_rk/")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model1")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model2")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model3")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model4")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model5")



os.chdir("/home/mfy/LMY/UTD/H3_s_sum/")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model1")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model2")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model3")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model4")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model5")




os.chdir("/home/mfy/LMY/UTD/H4_s_rk/")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model1")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model2")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model3")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model4")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model5")




os.chdir("/home/mfy/LMY/UTD/S1_2D kinect/")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model1")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model2")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model3")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model4")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model5")




os.chdir("/home/mfy/LMY/UTD/S2_3D kinect/")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model1")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model2")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model3")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model4")

os.system("mkdir model")
os.system("python train.py")
os.system("python test.py")
os.system("mv model model5")
