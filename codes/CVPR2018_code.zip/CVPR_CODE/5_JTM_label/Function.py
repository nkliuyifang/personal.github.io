#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 12 11:13:12 2017

@author: mfy
"""

import numpy as np

######################################################################
# Load Data
####################################### 
avg_pre = 0
for kk in range(1, 6):
	print(kk)
	labels_name = 'S1/model'+str(kk)+'/Label.npy'
	labels  = np.load(labels_name)

	pre_name_1 = 'S1/model'+str(kk)+'/Pre.npy'
	Predict_1 = np.load(pre_name_1)
    
	pre_name_2 = 'H3/model'+str(kk)+'/Pre.npy'
	Predict_2 = np.load(pre_name_2)

	Predict = Predict_1 * Predict_2

	preds = Predict.argmax(axis=1)  
	correct = np.sum(preds==labels)/(preds.size*1.0)
	print('correct: {}'.format(correct))
	avg_pre = avg_pre + correct
avg_pre /= 5
print('avg:{}'.format(avg_pre))
