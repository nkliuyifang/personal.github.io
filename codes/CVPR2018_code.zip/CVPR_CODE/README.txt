%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                                               
Feel free to contact liumengyuan@ntu.edu.sg if anything is unclear  
                                                               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

1. "CODE/1_avi_img/"
function: convert a video to a sequence of color images
prepare: put videos into "RGB/"
operate: double click run.bat
output: images in "data/"
note: ffmpeg.exe works under windows 64

2. "CODE/2_img_meta"
function: generate meta data (heatmaps of each joint) for each image
prepare: 
(a) move "data/" to this fold 
(b) git clone https://github.com/tensorboy/pytorch_Realtime_Multi-Person_Pose_Estimation.git
(c) download converted pytorch model (https://www.dropbox.com/s/ae071mfm2qoyc8v/pose_model.pth?dl=0)
(d) move "config" and "picture_demo.py" to main fold
operate: run "python picture_demo.py"
output: meta data in "data/"
note: different "config" and "pre-trained model" lead to slight different 2D skeletons

3. "CODE/3_data_feature"
prepare: move "data/" to this fold
operate: run "get_coordinate_org.m" and "get_heatmap.m"
output: "2D_RGB/", "map_t_rk/" and "map_s_rk/"
note: we impelement approximate rank pooling

4. "CODE/4_feature_JTM"
prepare: 
(a) move "2D_RGB/" to sub fold "H1/"
(b) move "map_t_rk/" to sub fold "H2/"
(c) move "map_s_rk/" to sub fold "H3/"
operate: run "run.m" in each sub fold
output: "subject/"
note: different datasets need different train/test settings

5. "CODE/5_JTM_label"
prepare:
(a) move "subject/" from fold "CODE/4_feature_JTM/H1/" to fold "CODE/5_JTM_label/H1"
(b) move "subject/" from fold "CODE/4_feature_JTM/H2/" to fold "CODE/5_JTM_label/H2"
(c) move "subject/" from fold "CODE/4_feature_JTM/H3/" to fold "CODE/5_JTM_label/H3"
operate: run "python sheet.py" and then run "python Function.py"
output: accuracy
note: different pre-trained model leads to different accuracies
