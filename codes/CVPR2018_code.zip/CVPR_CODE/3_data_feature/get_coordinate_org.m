clc;
clear;

Dir0 = dir(['data/']);
cor_dir = '2D_RGB'
mkdir(cor_dir);
for k = 3:size(Dir0,1)
    clc;
    disp([size(Dir0,1)-2 k-2]);
    Dir1 = dir(['data/',Dir0(k,1).name,'/*.mat']);

    heat_center = [];
    ct = 0;
    for j = 1:size(Dir1,1)
        file = ['data/',Dir0(k,1).name,'/',Dir1(j,1).name];
        load(file);
        if length(all_peaks) == 0
            continue;
        end
        ct = ct + 1;
        
        frame = zeros(14,2);
        for kk = 1:14          
           [aaa,bbb] = find(heatmap(:,:,kk)==max(max(heatmap(:,:,kk))));
           
           frame(kk,1) = aaa(1);
           frame(kk,2) = bbb(1);
        end
        
        heat_cor(:,:,j) = frame(:,1:2);
    end
    skeleton = [];
    skeleton = heat_cor;
    save([cor_dir,'/',Dir0(k,1).name],'skeleton');
end
