clc;
clear;

map_t_rk_dir = 'map_t_rk';
mkdir(map_t_rk_dir);

map_s_rk_dir = 'map_s_rk';
mkdir(map_s_rk_dir);



Dir00 = dir(['data/']);
for ss = 3:size(Dir00,1)
    clc;
    disp([size(Dir00,1)-2 ss-2]);
    Dir0 = dir(['data/',Dir00(ss,1).name,'/*.mat']);

    WIDTH = 480;
    HEIGHT = 440;
    LENGTH = size(Dir0,1);

    fw_w = zeros(1,WIDTH);
    for i=1:WIDTH
      fw_w(i) = sum((2*(i:WIDTH)-WIDTH-1) ./ (i:WIDTH));
    end

    fw_h = zeros(1,HEIGHT);
    for i=1:HEIGHT
      fw_h(i) = sum((2*(i:HEIGHT)-HEIGHT-1) ./ (i:HEIGHT));
    end

    fw_l = zeros(1,LENGTH);
    for i=1:LENGTH
      fw_l(i) = sum((2*(i:LENGTH)-LENGTH-1) ./ (i:LENGTH));
    end

    map_t_rk  = zeros(WIDTH,HEIGHT);

    map_s_rk  = zeros(WIDTH+HEIGHT,LENGTH);
        
    for k = 3:size(Dir0,1)
        file = ['data/',Dir00(ss,1).name,'/',Dir0(k,1).name];
        load(file);
        heatmap = heatmap(:,:,[1:14]);
        heatmap = sum(heatmap,3);

        map_t_rk = map_t_rk + fw_l(k) * heatmap;

        map_s_rk(:,k)  = [fw_w*heatmap,fw_h*heatmap']';
    end
    
    skeleton = [];
    skeleton = map_t_rk;
    save([map_t_rk_dir,'/',Dir00(ss,1).name],'skeleton');

    skeleton = [];
    skeleton = map_s_rk;
    save([map_s_rk_dir,'/',Dir00(ss,1).name],'skeleton');
    
end