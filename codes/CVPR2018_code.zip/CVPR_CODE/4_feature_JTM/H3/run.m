clc;
clear;
warning off;

input_dir = 'H3/';
output_dir = ['subject'];

mkdir(output_dir);
mkdir([output_dir,'/train']);
mkdir([output_dir,'/val']);
Dir = dir([input_dir,'/','*.mat']);
for k = 1:size(Dir,1)
   clc;
   disp([size(Dir,1) k]);

   % load data
   file = Dir(k,1).name;
   load([input_dir,'/',file]);

   image = imresize(skeleton,[224,224]);
   image = 255*(image-min(min(image)))./(eps+max(max(image))-min(min(image)));
   image = cat(3,image,image,image);
   image = uint8(image);

   % assign label
   fileNum = regexp(file,'\d*\.?\d*','match');
    
   % assign labels and set
   action = str2num(fileNum{1,1});
   subject = str2num(fileNum{1,2});

   % cross subject validation
   if mod(subject,2) == 1
       % train
       mkdir([output_dir,'/train/action',num2str(action)]);
       imwrite(image,[output_dir,'/train/action',num2str(action),'/',file(1,1:end-4),'.jpg']);
   else
       % test
       mkdir([output_dir,'/val/action',num2str(action)]);
       imwrite(image,[output_dir,'/val/action',num2str(action),'/',file(1,1:end-4),'.jpg']);
   end
end
