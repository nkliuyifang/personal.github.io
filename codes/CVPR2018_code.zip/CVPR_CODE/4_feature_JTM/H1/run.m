clc;
clear;
warning off;

input_dir = 'H1';
output_dir = ['subject'];

ORDER=[2 6;6 7;7 8;8 7;7 6;6 2;2 1;1 2;2 3;3 4;4 5;5 4;4 3;
    3 2;2 9;9 10;10 11;11 10;10 9;9 2;2 12;12 13;13 14;
    14 13;13 12;12 2];

mkdir(output_dir);
mkdir([output_dir,'/train']);
mkdir([output_dir,'/val']);
Dir = dir([input_dir,'/','*.mat']);
for k = 1:size(Dir,1)
   clc;
   disp([size(Dir,1) k]);

   % load data
   file = Dir(k,1).name;
   load([input_dir,'/',file]);
   
   
   if size(skeleton,3) < 5
       continue;
   end

   skeleton(:,3,:) = 0;
   image = calJTM(skeleton, ORDER);

   % assign label
   fileNum = regexp(file,'\d*\.?\d*','match');
    
   % assign labels and set
   action = str2num(fileNum{1,1});
   subject = str2num(fileNum{1,2});

   % cross subject validation
   if mod(subject,2) == 1
       % train
       mkdir([output_dir,'/train/action',num2str(action)]);
       imwrite(image,[output_dir,'/train/action',num2str(action),'/',file(1,1:end-4),'.jpg']);
   else
       % test
       mkdir([output_dir,'/val/action',num2str(action)]);
       imwrite(image,[output_dir,'/val/action',num2str(action),'/',file(1,1:end-4),'.jpg']);
   end
end
